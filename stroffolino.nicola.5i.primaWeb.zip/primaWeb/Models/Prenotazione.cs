public class Prenotazione {
    public string? Nome { get; set; }
    public string? Email { get; set; }
}